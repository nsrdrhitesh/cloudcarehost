<div>
    <!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div><?php /**PATH C:\xampp1\htdocs\HostingSeller\CloudCareHostLara1\resources\views/components/hosting-layout.blade.php ENDPATH**/ ?>