<!-- <div class="bg-gray-800 text-white py-2 text-sm">
    <div class="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-2">
        <div class="flex flex-wrap justify-center md:justify-start gap-4">
            <span><i class="fas fa-phone-alt text-indigo-500 mr-1"></i> +1 (800) 123-4567</span>
            <span><i class="fas fa-envelope text-indigo-500 mr-1"></i> support@cloudcarehost.com</span>
        </div>
        <div class="flex gap-4">
            <a href="<?php echo e(route('login')); ?>" class="text-white hover:text-indigo-400 transition-colors"><i
                    class="fas fa-sign-in-alt mr-1"></i> Login</a>
            <a href="<?php echo e(route('register')); ?>" class="text-white hover:text-indigo-400 transition-colors"><i
                    class="fas fa-user-plus mr-1"></i>
                Register</a>
        </div>
    </div>
</div> --><?php /**PATH C:\xampp1\htdocs\HostingSeller\CloudCareHostLara\resources\views/user/partials/top-bar.blade.php ENDPATH**/ ?>